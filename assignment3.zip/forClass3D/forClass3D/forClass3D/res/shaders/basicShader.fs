#version 130

varying vec2 texCoord0;
varying vec3 normal0;
varying vec3 color0;

uniform vec3 lightDirection;
uniform vec3 lightColor;
uniform sampler2D texture;

void main()
{
    //vec3 tmp = dot(-lightDirection, normal0) * color0 ;
	vec3 tmp = color0;
    if(texCoord0.x > 0.97f || texCoord0.x < 0.03f || texCoord0.y > 0.97f || texCoord0.y < 0.03f)
        gl_FragColor = clamp(vec4(0.0,0.0,0.0,1.0), 0.0, 1.0);
	else gl_FragColor =  clamp(vec4(tmp,1.0), 0.0, 1.0) ;
}