#pragma once   //maybe should be static class
#include "GLFW\glfw3.h"
	
	bool solvingInput = false;
	bool countinueFlag = false;
	void processPicking(double, double);
	void startIKsolver();
	void rotateJoints(int);
	void mouseTransformations(int, double, double);
	void restart();
	using namespace std;

	void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
	{
		switch (key)
		{
			case GLFW_KEY_ESCAPE:
				if(action == GLFW_PRESS)
					glfwSetWindowShouldClose(window,GLFW_TRUE);
				break;

			case GLFW_KEY_R:
				if(action == GLFW_PRESS)
					restart();
				break;

			case GLFW_KEY_SPACE:
				if(action == GLFW_PRESS ){
					if(solvingInput){
						cout << "IK solver had stopped." << endl;
						countinueFlag = true;			// We already stopped once.
						solvingInput = false;
					}else{
						if(countinueFlag)
							cout << "IK solver continues." << endl;
						solvingInput = true;
					}
				}
				break;

			// Rotations around previous link Z axis (first joint around the scene Z axis).
			// When nothing is picked rotate whole scene.
			case GLFW_KEY_RIGHT:
				rotateJoints(0);
				break;

			case GLFW_KEY_LEFT:
				rotateJoints(1);
				break;

			// Rotations according to euler angles - around current X axis.
			// When nothing is picked rotate whole scene.
			case GLFW_KEY_UP:
				rotateJoints(2);
				break;

			case GLFW_KEY_DOWN:
				rotateJoints(3);
				break;

			default:
				break;
		}
		
	}

	void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
	{
		double xx, yy;
		glfwGetCursorPos(window, &xx, &yy);
		if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
			processPicking(xx, yy);
	}

	void mouse_cursor_pos(GLFWwindow* window, double xx, double yy) {
		if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_RIGHT))
			mouseTransformations(0,xx,yy);
		if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT)) {
			mouseTransformations(1,xx,yy);
		}
	}



	void scroll_callback(GLFWwindow* window, double xoffset, double yoffset) {
		// where yoffset = vertical
		mouseTransformations(2, xoffset, yoffset);
	}