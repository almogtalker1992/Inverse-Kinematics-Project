#include <Windows.h>
#include <iostream>
#include "display.h"
#include "mesh.h"
#include "shader.h"
#include "inputManager.h"
#include "Texture.h"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/matrix_access.hpp> 
#include <glm/gtx/euler_angles.hpp>
#include <vector>
#include "stb_image.h"
#define M_PI        3.14159265358979323846264338327950288f   /* pi */
using namespace glm;

static const int DISPLAY_WIDTH = 800;
static const int DISPLAY_HEIGHT = 800;
struct colors {
	vec3 red = vec3(1, 0, 0);
	vec3 green = vec3(0, 1, 0);
	vec3 blue = vec3(0, 0, 1);
	vec3 orange = vec3(1, 0.5f, 0);
	vec3 yellow = vec3(1, 1, 0);
	vec3 white = vec3(1, 1, 1);
} colors;
Vertex vertices[] = {
	// Vertex(position,texCoord,normal,color)
	Vertex(vec3(-1, -1, -2), vec2(1, 0), vec3(0, 0, -1),colors.white),
	Vertex(vec3(-1, 1, -2), vec2(0, 0), vec3(0, 0, -1),colors.yellow),
	Vertex(vec3(1, 1, -2), vec2(0, 1), vec3(0, 0, -1),colors.yellow),
	Vertex(vec3(1, -1, -2), vec2(1, 1), vec3(0, 0, -1),colors.white),

	Vertex(vec3(-1, -1, 2), vec2(1, 0), vec3(0, 0, 1),colors.white),
	Vertex(vec3(-1, 1, 2), vec2(0, 0), vec3(0, 0, 1),colors.yellow),
	Vertex(vec3(1, 1, 2), vec2(0, 1), vec3(0, 0, 1),colors.yellow),
	Vertex(vec3(1, -1, 2), vec2(1, 1), vec3(0, 0, 1),colors.white),

	Vertex(vec3(-1, -1, -2), vec2(0, 1), vec3(0, -1, 0),colors.green),
	Vertex(vec3(-1, -1, 2), vec2(1, 1), vec3(0, -1, 0),colors.green),
	Vertex(vec3(1, -1, 2), vec2(1, 0), vec3(0, -1, 0),colors.blue),
	Vertex(vec3(1, -1, -2), vec2(0, 0), vec3(0, -1, 0),colors.blue),

	Vertex(vec3(-1, 1, -2), vec2(0, 1), vec3(0, 1, 0),colors.blue),
	Vertex(vec3(-1, 1, 2), vec2(1, 1), vec3(0, 1, 0),colors.blue),
	Vertex(vec3(1, 1, 2), vec2(1, 0), vec3(0, 1, 0),colors.green),
	Vertex(vec3(1, 1, -2), vec2(0, 0), vec3(0, 1, 0),colors.green),

	Vertex(vec3(-1, -1, -2), vec2(1, 1), vec3(-1, 0, 0),colors.orange),
	Vertex(vec3(-1, -1, 2), vec2(1, 0), vec3(-1, 0, 0),colors.orange),
	Vertex(vec3(-1, 1, 2), vec2(0, 0), vec3(-1, 0, 0),colors.red),
	Vertex(vec3(-1, 1, -2), vec2(0, 1), vec3(-1, 0, 0),colors.red),

	Vertex(vec3(1, -1, -2), vec2(1, 1), vec3(1, 0, 0),colors.red),
	Vertex(vec3(1, -1, 2), vec2(1, 0), vec3(1, 0, 0),colors.red),
	Vertex(vec3(1, 1, 2), vec2(0, 0), vec3(1, 0, 0),colors.orange),
	Vertex(vec3(1, 1, -2), vec2(0, 1), vec3(1, 0, 0),colors.orange) };
unsigned int indices[] = { 0, 1, 2,
0, 2, 3,

6, 5, 4,
7, 6, 4,

10, 9, 8,
11, 10, 8,

12, 13, 14,
12, 14, 15,

16, 17, 18,
16, 18, 19,

22, 21, 20,
23, 22, 20
};
Display display(DISPLAY_WIDTH, DISPLAY_HEIGHT, "IK Solver - Nir & Almog");
Mesh mesh(vertices, sizeof(vertices) / sizeof(vertices[0]), indices, sizeof(indices) / sizeof(indices[0]));
Shader shader("./res/shaders/basicShader");
Shader pickingShader("./res/shaders/pickingShader");
GLint viewport[4];
float currMouseX, currMouseY, prevMouseX, prevMouseY;
int num_of_meshes;
int picked_joint;
float mesh_depth;
float far_, near_, relation, xrel, yrel, CAM_ANGLE, z, transX, transY; // Mouse translations
vector<mat4> mesh_translation;
vector<mat4> mesh_rotation;
vector<mat4> z_mat;
vector<mat4> x_mat;
vector<mat4> mesh_transformations;
mat4 P, M, MVP;
vector<vec3> points;													// Joints base points
vec3 E, T;																// E - effector joint, T - target joint
Texture texture_1("./res/textures/1.jpg");
Texture texture_2("./res/textures/Poop_Emoji.png");

void drawWorldAxises() {
	glLineWidth(2.5);
	glColor3f(1, 1, 1);
	glBegin(GL_LINES);
	glVertex3f(10, 0, 0);
	glVertex3f(-10, 0, 0);
	glEnd();
	glBegin(GL_LINES);
	glVertex3f(0, 10, 0);
	glVertex3f(0, -10, 0);
	glEnd();
}

void drawAxises() {
	glLineWidth(1.5); 
	glColor3f(1, 1, 1);
	glBegin(GL_LINES);
	glVertex3f(-5, 0,-2 );
	glVertex3f(5, 0, -2);
	glEnd();
	glBegin(GL_LINES);
	glVertex3f(0, 5, -2);
	glVertex3f(0, -5, -2);
	glEnd();
}

void restart(){
	currMouseX = 0;
	currMouseY = 0;
	prevMouseY = 0;
	prevMouseX = 0;
	num_of_meshes = 5;
	picked_joint = -1;											//	By default point to background - whole scene
	far_ = 100.f;
	near_ = 0.1f;
	solvingInput = false;
	relation = (float)DISPLAY_WIDTH / (float)DISPLAY_HEIGHT;
	CAM_ANGLE = 60.f;
	xrel = (float)(prevMouseX - currMouseX), yrel = (float)(prevMouseY - currMouseY);
	z = far_ + mesh_depth*(near_ - far_);
	transX = relation*(xrel) / (float)(viewport[2])*near_*2.0f*tan(CAM_ANGLE*M_PI / 360.0f)*(far_ / z);
	transY = (yrel) / (float)(viewport[3])*near_*2.0f*tan(CAM_ANGLE*M_PI / 360.0f)*(far_ / z);
	mesh_translation = vector<mat4>(num_of_meshes, mat4(1));	//	Translation matrix for each mesh
	mesh_rotation = vector<mat4>(num_of_meshes, mat4(1));		//	Rotation matrix for each mesh
	z_mat = vector<mat4>(num_of_meshes, mat4(1));		
	x_mat = vector<mat4>(num_of_meshes, mat4(1));
	points = vector<vec3>(num_of_meshes, vec3(0));
	// Transformations = translations * rotations for each mesh
	mesh_transformations = vector<mat4>(num_of_meshes, mat4(1));
	mesh_translation.at(0) = translate(vec3(5.f, 0.f, 0.f));
	mesh_translation.at(1) = translate(vec3(0.f, 0.f, 0.f));
	vec3 pos = vec3(0, 10, -30);
	vec3 forward = vec3(0.0f, 0.0f, 1.0f);
	vec3 up = vec3(0.0f, 1.0f, 0.0f);
	P = perspective(60.f, (float)DISPLAY_WIDTH / (float)DISPLAY_HEIGHT, 0.1f, 100.f);
	P = P * lookAt(pos, pos + forward, up);
	P = rotate(P, 90.f, vec3(-1, 0, 0));
	for (int i = 0; i < num_of_meshes; i++) 
		points.at(i) = vec3(0,0,i*4);				//starting at (0,0,0)
	E = points.at(num_of_meshes-1);
	T = vec3(1);
}

void draw() {
	display.Clear(1.f, 1.f, 1.f, 1.f);
	// Draw world coordinates
	M = mat4(1);
	MVP = P*M;
	shader.Bind();
	shader.Update(MVP, M, -1);
	drawWorldAxises();

	// Mesh 0 - Target mesh!
	mesh_transformations.at(0) = scale(vec3(1, 1, 0.5f)) * mesh_translation.at(0) * z_mat.at(0) * x_mat.at(0) * transpose(z_mat.at(0));
	M = translate(vec3(1, 0, 0.5f)) * mesh_transformations.at(0);
	vec4 tmp = translate(vec3(0, 0, -1)) * mesh_transformations.at(0) * vec4(1, 1, 1, 1);
	T =  vec3(tmp.x, tmp.y, tmp.z);
	MVP = P * M;
	texture_2.Bind(0);
	shader.Bind();
	shader.Update(MVP, M, -1);
	mesh.Draw();
	drawAxises();

	// Mesh 1 - Base mesh!
	mesh_transformations.at(1) = mesh_translation.at(1) * mesh_rotation.at(1) * z_mat.at(1) * x_mat.at(1) * transpose(z_mat.at(1));
	M = mesh_transformations.at(1);
	MVP = P * M;
	shader.Bind();
	texture_1.Bind(0);
	shader.Update(MVP, M, -1);
	mesh.Draw();
	drawAxises();

	// The rest of the meshes
	for (int i = 2; i < num_of_meshes; i++) {
		mat4 M1 = translate(vec3(0, 0, 4));
		mesh_transformations.at(i) = mesh_transformations.at(i - 1) * M1 * mesh_rotation.at(i) * z_mat.at(i) * x_mat.at(i) * transpose(z_mat.at(i));
		M = mesh_transformations.at(i);
		MVP = P * M;
		texture_1.Bind(0);
		shader.Bind();
		shader.Update(MVP, M, -1);
		mesh.Draw();
		// Draw each mesh coordinates
		drawAxises();
	}
	vec4 p_i = translate(vec3(0, 0, -2)) * mesh_transformations.at(num_of_meshes - 1) * vec4(1, 1, 1, 1);
	
	E = vec3(p_i.x, p_i.y, p_i.z);
	display.SwapBuffers();
}

void startIKsolver(){
	vec4 p_i = translate(vec3(0, 0, -2)) * mesh_transformations.at(1) * vec4(1, 1, 1, 1);
	points.at(0) = vec3(p_i.x, p_i.y, p_i.z);
	if (abs(length(T - points.at(0)) > (num_of_meshes - 1) * 4))
		cout << "Can't reach!" << endl;
	else {
		vec3 u_i, v_i, w_i;
		float angle;
		int counter = 0;
		if (abs(length(T - E)) > 0.1 && solvingInput) {
			for (size_t i = num_of_meshes - 1; i > 0; i--)
			{
				vec4 p_i = translate(vec3(0, 0, -2)) * mesh_transformations.at(i) * vec4(1, 1, 1, 1);
				points.at(i) = vec3(p_i.x, p_i.y, p_i.z);
				u_i = E - points.at(i - 1);
				v_i = T - points.at(i - 1);
				w_i = normalize(cross(normalize(u_i), normalize(v_i)));
				float A = dot(u_i, v_i) / (length(u_i)*length(v_i));
				if (A > 1.f) A = 1.f;
				else if (A < -1.f) A = -1.f;
				angle = acos(A) / 2;
				mesh_rotation.at(i) = translate(vec3(0, 0, -2)) * rotate(angle, w_i) * translate(vec3(0, 0, 2)) * mesh_rotation.at(i);
				if (i == 0) i = num_of_meshes - 1;
			}
		}
		else {
			cout << "WE GOT IT!!!" << endl;
			countinueFlag = false;
			solvingInput = false;
		}
	
	}
}

void mouseTransformations(int direction, double xx, double yy) {
	vec3 move;
	prevMouseX = currMouseX;
	prevMouseY = currMouseY;
	currMouseX = (float)xx;
	currMouseY = (float)yy;
	xrel = (float)(prevMouseX - currMouseX), yrel = (float)(prevMouseY - currMouseY);
	switch (direction) {
		case 0:	// Translate the joints
			z = far_ + mesh_depth*(near_ - far_);
			transX = (float)(relation*(xrel) / (float)(viewport[2])*near_*2.0f*tan(CAM_ANGLE*M_PI / 360.0)*(far_ / z));
			transY = (float)((yrel) / (float)(viewport[3])*near_*2.0f*tan(CAM_ANGLE*M_PI / 360.0)*(far_ / z));
			if (picked_joint >= 1) {
				move = vec3(transX, 0, transY);
				mesh_translation.at(1) = translate(mesh_translation.at(1), move);
			}
			else if (picked_joint == 0) {
				move = vec3(transX, 0, 2 * transY);
				mesh_translation.at(0) =  translate(mesh_translation.at(0), move);
	
			} 
			break;
		case 1: // Rotate the joints
			if (picked_joint >= 0) {
				x_mat.at(picked_joint) = translate(vec3(0, 0, -2)) * rotate(xrel, vec3(1, 0, 0)) * translate(vec3(0, 0, 2)) * x_mat.at(picked_joint);
				z_mat.at(picked_joint) = translate(vec3(0, 0, -2)) * rotate(yrel, vec3(0, 0, 1)) * translate(vec3(0, 0, 2)) * z_mat.at(picked_joint);
			} else P = rotate(P, 10.0f, vec3(0, 0, 1));
			break;
		case 2:
			if (picked_joint == 0) {
				// Update mouse to the change in target mesh
				currMouseX += prevMouseX;
				currMouseY += prevMouseY;
				move = vec3(xx, yy, 0);
				mesh_translation.at(0) = translate(mesh_translation.at(0), move);
			}else if (picked_joint > 0) {
				// Update mouse to the change in joints
				currMouseX += prevMouseX;
				currMouseY += prevMouseY;
				move = vec3(xx, yy, 0);
				mesh_translation.at(1) = translate(mesh_translation.at(1), move);
			}
			break;
		default:
			break;
	}
}

void rotateJoints(int direction) {

	switch (direction) {
		case 0:  // Right Rotation
			if (picked_joint > 0) 
				z_mat.at(picked_joint) = translate(vec3(0, 0, -2)) * rotate(-10.0f, vec3(0, 0, 1)) * translate(vec3(0, 0, 2)) * z_mat.at(picked_joint);
			else P = rotate(P, 10.0f, vec3(0, 0, 1));
			break;
		case 1: // Left Rotation
			if (picked_joint > 0)
				z_mat.at(picked_joint) = translate(vec3(0, 0, -2)) * rotate(10.0f, vec3(0, 0, 1)) * translate(vec3(0, 0, 2)) * z_mat.at(picked_joint);
			else P = rotate(P, 10.0f, vec3(0, 0, -1));
			break;
		case 2: // Up Rotation	
			if (picked_joint > 0)
				x_mat.at(picked_joint) = translate(vec3(0, 0, -2)) * rotate(10.0f, vec3(1, 0, 0)) * translate(vec3(0, 0, 2)) * x_mat.at(picked_joint);
			else P = rotate(P, 10.0f, vec3(1, 0, 0)); 
			break;
		case 3: // Down Rotation
			if (picked_joint > 0)
				x_mat.at(picked_joint) = translate(vec3(0, 0, -2)) * rotate(-10.0f, vec3(1, 0, 0)) * translate(vec3(0, 0, 2)) * x_mat.at(picked_joint);
			else P = rotate(P, 10.0f, vec3(-1, 0, 0));
			break;
		default:
			break;
	}
}

void processPicking(double xx, double yy) {
	// Clear the screen to black
	glClearColor(0.f, 0.f, 0.f, 0.f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	/* Placing meshes in the world (back buffer) */

	currMouseX = (float)xx;
	currMouseY = (float)yy;

	// Mesh 0 - Target mesh!
	mesh_transformations.at(0) = scale(vec3(1, 1, 0.5f)) * mesh_translation.at(0) * z_mat.at(0) * x_mat.at(0) * transpose(z_mat.at(0));
	M = translate(vec3(1, 0, 0.5f)) * mesh_transformations.at(0);
	MVP = P * M;
	pickingShader.Bind();
	pickingShader.Update(MVP, M, 1);
	mesh.Draw();

	// Mesh 1 - Base mesh!
	mesh_transformations.at(1) = mesh_translation.at(1) * mesh_rotation.at(1) * z_mat.at(1) * x_mat.at(1) * transpose(z_mat.at(1));
	M = mesh_transformations.at(1);
	MVP = P * M;
	pickingShader.Bind();
	pickingShader.Update(MVP, M, 2);
	mesh.Draw();

	// The rest of the meshes
	for (int i = 2; i < num_of_meshes; i++) {
		mat4 M1 = translate(vec3(0, 0, 4));
		mesh_transformations.at(i) = mesh_transformations.at(i - 1) * M1 * mesh_rotation.at(i) * z_mat.at(i) * x_mat.at(i) *transpose(z_mat.at(i));
		M = mesh_transformations.at(i);
		MVP = P * M;
		pickingShader.Bind();
		pickingShader.Update(MVP, M, i+1);
		mesh.Draw();
	}

	/* Determine which mesh has been picked up (by unique color) */

	glFlush();
	glFinish(); 
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	unsigned char data[4];
	glGetIntegerv(GL_VIEWPORT, viewport);
	glReadPixels((GLint)currMouseX, (GLint)(viewport[3] - currMouseY), 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, data);
	glReadPixels((GLint)currMouseX, (GLint)(viewport[3] - currMouseY), 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &mesh_depth);

	std::cout << "Depth: " << mesh_depth << std::endl;
	std::cout << "X: " << xx << std::endl;
	std::cout << "Y: " << yy << std::endl;
	// Convert the color back to an integer ID
	int pickedID = data[0] + data[1] * 256 + data[2] * 256*256 - 1;
	if (pickedID == 0xffffffff) {
		picked_joint = -1;
		std::cout << "background" << std::endl;
	}
	else{
		picked_joint = pickedID;
		std::cout << "mesh " << pickedID << std::endl;
	}	
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
}


int main(int argc, char** argv)
{
	restart();
	glfwSetKeyCallback(display.m_window,key_callback);
	glfwSetMouseButtonCallback(display.m_window, mouse_button_callback);
	glfwSetCursorPosCallback(display.m_window, mouse_cursor_pos);
	glfwSetScrollCallback(display.m_window, scroll_callback);
	int counter = 0;
	while(!glfwWindowShouldClose(display.m_window))
	{
		Sleep(3);
		draw();
		glfwPollEvents();
		if (solvingInput) {	
			startIKsolver();
			counter++;
			if (counter == 100) {
				cout << "Distance to target: " << abs(length(T - E)) << endl;
				counter = 0;
			}
		}
	}
	return 0;
}





